#include "gamewindow.h"
#include "settingswindow.h"
#include "ui_gamewindow.h"

#include <windows.h>
#include <QDialog>
GameWindow::GameWindow(std::string& name, std::string& surname, QMainWindow* prev, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::GameWindow),
    prev_(prev),
    player_(name, surname)
{
    ui->setupUi(this);
    setAttribute(Qt::WA_DeleteOnClose, true);
    player_.Read();

    ui->account->setText("Account: " +
       QString::fromStdString(name) + " " + QString::fromStdString(surname));

    stop = false;
    future_per_second = std::async([=](){
        while (true) {
            if (stop)
                break;
            player_.GivePerSecond();
            ui->click->setText("x" + QString::fromStdString(std::to_string(player_.getTapFactor())));
            UpdatePoints();
            Sleep(1000);
        }
    });

    UpdatePoints();
    UpdateBoostButtons();
    UpdatePerSecond();
    UpdatePerClick();
}

void GameWindow::UpdatePoints() {
    ui->points->setText(QString::fromStdString(player_.getPoints().ToShortString())
          + " " + QString::fromStdString(player_.getSkin().getPointsName())
    );
}

void GameWindow::UpdateBoostButtons() {
    ui->boost1_button->setText(player_.PassiveBoostInfo(0));
    ui->boost2_button->setText(player_.PassiveBoostInfo(1));
    ui->boost3_button->setText(player_.PassiveBoostInfo(2));
    ui->boost4_button->setText(player_.PassiveBoostInfo(3));
    ui->boost5_button->setText(player_.PassiveBoostInfo(4));
    ui->boost6_button->setText(player_.PassiveBoostInfo(5));
    ui->boost7_button->setText(player_.PassiveBoostInfo(6));
    ui->boost8_button->setText(player_.PassiveBoostInfo(7));
    ui->boost9_button->setText(player_.PassiveBoostInfo(8));
    ui->boost10_button->setText(player_.PassiveBoostInfo(9));
    ui->click_boost->setText(player_.ClickBoostInfo());
}

void GameWindow::UpdatePerSecond() {
    ui->per_second_label->setText("Per sec: "
            + QString::fromStdString(player_.getPerSecond().ToShortString()) + " "
            + QString::fromStdString(player_.getSkin().getPointsName())
    );
}

GameWindow::~GameWindow() {
    delete ui;
    //std::cout << "GameWindow" << std::endl;
    stop = true;
    player_.Write();
}

void GameWindow::on_click_clicked() {
    player_.Click();
    UpdatePoints();
}

void GameWindow::ChangeSkin(const std::string& skin) {
    player_.getSkin().Change(skin);
    UpdatePoints();
    UpdatePerSecond();
    UpdateBoostButtons();
    UpdatePerClick();
}

void GameWindow::on_pushButton_clicked() {
    ChangeSkin("шайба");
}

void GameWindow::on_pushButton_2_clicked() {
    ChangeSkin("coin");
}

void GameWindow::on_click_boost_clicked() {
    player_.BuyClickBoost();
    UpdatePoints();
    UpdatePerClick();
    UpdateClickButton();
}

void GameWindow::UpdatePerClick() {
    ui->per_click->setText("Per click: " + QString::fromStdString(player_.getPerClick().ToShortString())
                     + " " + QString::fromStdString(player_.getSkin().getPointsName())
    );
}

void GameWindow::UpdateClickButton() {
    ui->click_boost->setText(player_.ClickBoostInfo());
}

void GameWindow::on_settings_button_clicked() {
    SettingsWindow* sw = new SettingsWindow(this);
    sw->show();
}

QMainWindow* GameWindow::getRegistrationWindow() {
    return prev_;
}

//void GameWindow::setStop(bool f) {
  //  stop = f;
//}
