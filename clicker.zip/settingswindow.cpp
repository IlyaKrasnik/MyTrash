#include "settingswindow.h"
#include "ui_settingswindow.h"

SettingsWindow::SettingsWindow(GameWindow* game_, QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SettingsWindow),
    game(game_) {
    ui->setupUi(this);
    setAttribute(Qt::WA_DeleteOnClose, true);
    this->setWindowModality(Qt::ApplicationModal);
}

SettingsWindow::~SettingsWindow() {
    delete ui;
    //std::cout << "SettingsWindow" << std::endl;
}

void SettingsWindow::on_back_to_game_button_clicked() {
    this->close();
}

void SettingsWindow::on_resolution_button_clicked() {
    if (game->isFullScreen()) {
        game->showNormal();
        this->raise();
    } else {
        game->showFullScreen();
        this->raise();
    }
}

void SettingsWindow::on_change_account_button_clicked() {
    QMainWindow* qmw = game->getRegistrationWindow();
    //game->setStop(true);
    this->close();
    game->close();
    qmw->show();
}



void SettingsWindow::on_exit_button_clicked() {
    this->close();
    game->close();
}
